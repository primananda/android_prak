<?php
include '../config/connection.php';

$judul = addslashes(htmlentities($_POST['judul']));
$genre = addslashes(htmlentities($_POST['genre']));
$tahun = addslashes(htmlentities($_POST['tahun']));
$durasi = addslashes(htmlentities($_POST['durasi']));
$images = addslashes(htmlentities($_POST['images']));

$insert = "insert into film(judul,genre,tahun,durasi,images) values('$judul','$genre','$tahun','$durasi','$images')";

$result = mysqli_query($conn, $insert);


$response = array();
if($result){
    $response['status'] = "success";
    $response['code'] = 1;
    $response['message'] = "Berhasil Menambah Data";
}else{
    $response['status'] = "failed";
    $response['code'] = 0;
    $response['message'] = "Gagal Menambah Data";
}

echo json_encode($response);