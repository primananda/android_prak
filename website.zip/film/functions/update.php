<?php
include '../config/connection.php';

$id = addslashes(htmlentities($_POST['id']));
$judul = addslashes(htmlentities($_POST['judul']));
$genre = addslashes(htmlentities($_POST['genre']));
$tahun = addslashes(htmlentities($_POST['tahun']));
$durasi = addslashes(htmlentities($_POST['durasi']));

$update = "update film set judul='$judul', genre='$genre', tahun='$tahun', durasi='$durasi' where id='$id'";

$result = mysqli_query($conn, $update);

$response = array();
if($result){
    $response['status'] = "success";
    $response['code'] = 1;
    $response['message'] = "Berhasil Mengubah Data";
}else{
    $response['status'] = "failed";
    $response['code'] = 0;
    $response['message'] = "Gagal Mengubah Data";
}

echo json_encode($response);